const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const cors = require('cors');
const http = require('http');
const net = require('net');
const crypto = require('crypto');
const session = require('express-session');
const { exec } = require('child_process');

const app = express();
app.set('trust proxy', 1);
app.use(cors({ credentials: true, origin: function(o,cb){cb(null,true);} }));
app.use(express.json({ limit: '10mb' }));

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/open5gs';
const PORT = process.env.PORT || 3001;
const SESSION_SECRET = process.env.SESSION_SECRET || 'open5gs-dash-' + crypto.randomBytes(8).toString('hex');
const PROM = 'http://metrics:9090';

let db;
MongoClient.connect(MONGO_URI, { serverSelectionTimeoutMS: 5000 })
  .then(async client => {
    db = client.db('open5gs');
    console.log('Connected to MongoDB');
    await ensureDefaultAdmin();
    await db.collection('audit_log').createIndex({ ts: -1 });
  })
  .catch(err => console.error('MongoDB connection failed:', err.message));

// ── Auth helpers ──────────────────────────────────────────────────────────────
function hashPassword(password, salt) {
  if (!salt) salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.createHmac('sha256', salt).update(password).digest('hex');
  return { hash, salt };
}
function verifyPassword(password, salt, storedHash) {
  return hashPassword(password, salt).hash === storedHash;
}
async function ensureDefaultAdmin() {
  const count = await db.collection('dashboard_users').countDocuments();
  if (count === 0) {
    const { hash, salt } = hashPassword('admin');
    await db.collection('dashboard_users').insertOne({
      username: 'admin', hash, salt, role: 'admin',
      createdAt: new Date(), mustChangePassword: true,
    });
    console.log('Default admin created (admin/admin)');
  }
}

// ── Audit log ─────────────────────────────────────────────────────────────────
async function audit(req, action, detail) {
  try {
    await db.collection('audit_log').insertOne({
      ts: new Date(),
      user: req.session?.username || 'system',
      action,
      detail,
      ip: req.ip,
    });
  } catch(_) {}
}

// ── Sessions ──────────────────────────────────────────────────────────────────
app.use(session({
  name: 'open5gs.sid',
  secret: SESSION_SECRET,
  resave: true,
  saveUninitialized: false,
  rolling: true,
  cookie: { httpOnly: true, maxAge: 1000*60*60*8, sameSite: 'lax', secure: false, path: '/' },
}));

function requireAuth(req, res, next) {
  if (req.session && req.session.userId) return next();
  res.status(401).json({ error: 'Unauthorized' });
}
function requireAdmin(req, res, next) {
  if (req.session?.role === 'admin') return next();
  res.status(403).json({ error: 'Admin required' });
}

// ── TCP / HTTP / Docker helpers ───────────────────────────────────────────────
function tcpCheck(host, port, ms=3000) {
  return new Promise(resolve => {
    const s = new net.Socket(); let done = false;
    const fin = r => { if(done)return; done=true; s.destroy(); resolve(r); };
    s.setTimeout(ms);
    s.connect(port, host, ()=>fin('running'));
    s.on('error',()=>fin('stopped'));
    s.on('timeout',()=>fin('stopped'));
  });
}
function httpCheck(url, ms=3000) {
  return new Promise(resolve => {
    const r = http.get(url, {timeout:ms}, res => resolve(res.statusCode<500?'running':'stopped'));
    r.on('error',()=>resolve('stopped'));
    r.on('timeout',()=>{r.destroy();resolve('stopped');});
  });
}
function dockerInspect(name) {
  return new Promise(resolve => {
    const r = http.request({socketPath:'/var/run/docker.sock',path:`/containers/${name}/json`,method:'GET'}, res=>{
      let d=''; res.on('data',c=>d+=c);
      res.on('end',()=>{ try{resolve(JSON.parse(d));}catch{resolve(null);} });
    });
    r.on('error',()=>resolve(null)); r.end();
  });
}
function dockerAction(name, action) {
  return new Promise(resolve => {
    const r = http.request({socketPath:'/var/run/docker.sock',path:`/containers/${name}/${action}`,method:'POST'}, res=>{
      resolve({ok: res.statusCode===204||res.statusCode===200, status:res.statusCode});
    });
    r.on('error',e=>resolve({ok:false,error:e.message})); r.end();
  });
}
function dockerStats(name) {
  return new Promise(resolve => {
    const r = http.request({socketPath:'/var/run/docker.sock',path:`/containers/${name}/stats?stream=false`,method:'GET'}, res=>{
      let d=''; res.on('data',c=>d+=c);
      res.on('end',()=>{
        try {
          const s = JSON.parse(d);
          const cpuDelta = s.cpu_stats.cpu_usage.total_usage - s.precpu_stats.cpu_usage.total_usage;
          const sysDelta = s.cpu_stats.system_cpu_usage - s.precpu_stats.system_cpu_usage;
          const cpuCount = s.cpu_stats.online_cpus || s.cpu_stats.cpu_usage.percpu_usage?.length || 1;
          const cpu = ((cpuDelta/sysDelta)*cpuCount*100).toFixed(1);
          const memUsage = s.memory_stats.usage - (s.memory_stats.stats?.cache||0);
          const memLimit = s.memory_stats.limit;
          const memPct = ((memUsage/memLimit)*100).toFixed(1);
          const memMB = (memUsage/1024/1024).toFixed(0);
          resolve({ cpu: parseFloat(cpu), memMB: parseFloat(memMB), memPct: parseFloat(memPct) });
        } catch { resolve(null); }
      });
    });
    r.on('error',()=>resolve(null)); r.end();
  });
}
function promQuery(metric) {
  return new Promise(resolve => {
    const url = PROM+'/api/v1/query?query='+encodeURIComponent(metric);
    http.get(url,{timeout:3000},res=>{
      let d=''; res.on('data',c=>d+=c);
      res.on('end',()=>{
        try {
          const j=JSON.parse(d);
          const result=j.data&&j.data.result;
          if(result&&result.length>0) resolve(result.reduce((s,r)=>s+parseFloat(r.value[1]||0),0)|0);
          else resolve(null);
        } catch{resolve(null);}
      });
    }).on('error',()=>resolve(null)).on('timeout',()=>resolve(null));
  });
}
function promQueryRaw(metric) {
  return new Promise(resolve => {
    http.get(PROM+'/api/v1/query?query='+encodeURIComponent(metric),{timeout:3000},res=>{
      let d=''; res.on('data',c=>d+=c);
      res.on('end',()=>{ try{resolve(JSON.parse(d).data.result||[]);}catch{resolve([]);} });
    }).on('error',()=>resolve([])).on('timeout',()=>resolve([]));
  });
}

// ── Discover PyHSS URL ────────────────────────────────────────────────────────
let pyhssUrl = null;
async function discoverPyHSS() {
  // PyHSS API runs on port+1 from config port (8080+1=8081 per PyHSS docs)
  for (const url of ['http://pyhss:8081','http://pyhss:8080','http://pyhss:5000']) {
    const s = await httpCheck(url);
    if (s === 'running') { pyhssUrl = url; console.log('PyHSS API found at', url); return; }
  }
  console.log('PyHSS API not discovered');
}
setTimeout(discoverPyHSS, 3000);

function pyhssFetch(path, opts={}) {
  return new Promise((resolve,reject) => {
    if (!pyhssUrl) return reject(new Error('PyHSS not available'));
    const url = new URL(pyhssUrl+path);
    const options = {
      hostname: url.hostname, port: url.port||80,
      path: url.pathname+url.search, method: opts.method||'GET',
      headers: { 'Content-Type':'application/json', 'Provisioning-Key': 'hss', ...(opts.headers||{}) },
      timeout: 5000,
    };
    const req = http.request(options, res => {
      let d=''; res.on('data',c=>d+=c);
      res.on('end',()=>{
        try { resolve({ status: res.statusCode, body: JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, body: d }); }
      });
    });
    req.on('error',reject);
    req.on('timeout',()=>{req.destroy();reject(new Error('Timeout'));});
    if (opts.body) req.write(JSON.stringify(opts.body));
    req.end();
  });
}

// ── Uptime helper ─────────────────────────────────────────────────────────────
function calcUptime(startedAt) {
  if (!startedAt) return null;
  const ms = Date.now() - new Date(startedAt).getTime();
  const s = Math.floor(ms/1000);
  const d = Math.floor(s/86400), h = Math.floor((s%86400)/3600), m = Math.floor((s%3600)/60);
  if (d>0) return d+'d '+h+'h '+m+'m';
  if (h>0) return h+'h '+m+'m';
  return m+'m '+(s%60)+'s';
}

// ════════════════════════════════════════════════════════════════════════════════
// AUTH ROUTES
// ════════════════════════════════════════════════════════════════════════════════
app.post('/api/auth/login', async (req,res) => {
  const {username,password} = req.body;
  if (!username||!password) return res.status(400).json({error:'Username and password required'});
  try {
    if (!db) return res.status(503).json({error:'Database not connected'});
    const account = await db.collection('dashboard_users').findOne({username});
    if (!account||!verifyPassword(password,account.salt,account.hash))
      return res.status(401).json({error:'Invalid username or password'});
    req.session.userId = account._id.toString();
    req.session.username = account.username;
    req.session.role = account.role;
    req.session.save(err => {
      if (err) return res.status(500).json({error:'Session error'});
      audit(req,'login',`User ${username} logged in`);
      res.json({ok:true,username:account.username,role:account.role,mustChangePassword:!!account.mustChangePassword});
    });
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/api/auth/logout', (req,res) => {
  const user = req.session?.username;
  req.session.destroy(()=>{
    if(user&&db) db.collection('audit_log').insertOne({ts:new Date(),user,action:'logout',detail:'Logged out',ip:req.ip}).catch(()=>{});
    res.json({ok:true});
  });
});
app.get('/api/auth/me', (req,res) => {
  if (req.session?.userId) res.json({loggedIn:true,username:req.session.username,role:req.session.role});
  else res.json({loggedIn:false});
});
app.post('/api/auth/change-password', requireAuth, async (req,res) => {
  const {currentPassword,newPassword} = req.body;
  if (!newPassword||newPassword.length<6) return res.status(400).json({error:'Password must be at least 6 characters'});
  try {
    const account = await db.collection('dashboard_users').findOne({_id:new ObjectId(req.session.userId)});
    if (!account) return res.status(404).json({error:'Account not found'});
    if (!account.mustChangePassword) {
      if (!currentPassword) return res.status(400).json({error:'Current password required'});
      if (!verifyPassword(currentPassword,account.salt,account.hash))
        return res.status(401).json({error:'Current password incorrect'});
    }
    const {hash,salt} = hashPassword(newPassword);
    await db.collection('dashboard_users').updateOne({_id:new ObjectId(req.session.userId)},{$set:{hash,salt,mustChangePassword:false}});
    await audit(req,'change-password','Password changed');
    res.json({ok:true});
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// USER MANAGEMENT
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/users', requireAuth, requireAdmin, async (req,res) => {
  try {
    res.json(await db.collection('dashboard_users').find({},{projection:{hash:0,salt:0}}).toArray());
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/api/users', requireAuth, requireAdmin, async (req,res) => {
  const {username,password,role} = req.body;
  if (!username||!password) return res.status(400).json({error:'Username and password required'});
  try {
    if (await db.collection('dashboard_users').findOne({username})) return res.status(409).json({error:'Username exists'});
    const {hash,salt} = hashPassword(password);
    const result = await db.collection('dashboard_users').insertOne({username,hash,salt,role:role||'user',createdAt:new Date(),mustChangePassword:false});
    await audit(req,'create-user',`Created user ${username}`);
    res.json({ok:true,_id:result.insertedId,username,role:role||'user'});
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.delete('/api/users/:id', requireAuth, requireAdmin, async (req,res) => {
  try {
    if (req.params.id===req.session.userId) return res.status(400).json({error:'Cannot delete own account'});
    const user = await db.collection('dashboard_users').findOne({_id:new ObjectId(req.params.id)});
    await db.collection('dashboard_users').deleteOne({_id:new ObjectId(req.params.id)});
    await audit(req,'delete-user',`Deleted user ${user?.username}`);
    res.json({ok:true});
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/api/users/:id/reset-password', requireAuth, requireAdmin, async (req,res) => {
  const {newPassword} = req.body;
  if (!newPassword||newPassword.length<6) return res.status(400).json({error:'Min 6 characters'});
  try {
    const {hash,salt} = hashPassword(newPassword);
    await db.collection('dashboard_users').updateOne({_id:new ObjectId(req.params.id)},{$set:{hash,salt,mustChangePassword:true}});
    await audit(req,'reset-password',`Reset password for user ${req.params.id}`);
    res.json({ok:true});
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// SESSION VIEWER
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/sessions', requireAuth, requireAdmin, async (req,res) => {
  // express-session memory store doesn't expose sessions directly
  // Return current session info + note
  res.json([{
    id: req.session.id,
    username: req.session.username,
    role: req.session.role,
    current: true,
    ip: req.ip,
  }]);
});

// ════════════════════════════════════════════════════════════════════════════════
// AUDIT LOG
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/audit', requireAuth, requireAdmin, async (req,res) => {
  try {
    const limit = parseInt(req.query.limit)||100;
    const logs = await db.collection('audit_log').find({}).sort({ts:-1}).limit(limit).toArray();
    res.json(logs);
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// STATS
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/stats', requireAuth, async (req,res) => {
  try {
    if (!db) return res.status(503).json({error:'DB not connected'});
    const totalSubscribers = await db.collection('subscribers').countDocuments();
    const [enbCount,ueCount,sessionCount,uesActive] = await Promise.all([
      promQuery('enb'), promQuery('enb_ue'),
      promQuery('mme_session'), promQuery('ues_active'),
    ]);
    res.json({
      totalSubscribers, connectedENBs:enbCount, connectedUEs:ueCount,
      activeSessions: sessionCount!==null?sessionCount:(uesActive||0),
      mongoConnected:!!db,
    });
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// CONTAINERS — status, control, resources
// ════════════════════════════════════════════════════════════════════════════════
const ALLOWED_CONTAINERS = ['mme','smf','upf','sgwc','sgwu','pcrf','pcscf','icscf','scscf',
  'smsc','osmomsc','osmohlr','pyhss','rtpengine','dns','metrics','grafana','mongo','webui'];

app.get('/api/containers/status', requireAuth, async (req,res) => {
  const results = await Promise.all(ALLOWED_CONTAINERS.map(async name => {
    const info = await dockerInspect(name);
    if (!info) return null;
    const state = info.State||{};
    return {
      name, running:state.Running===true, status:state.Status||'unknown',
      uptime:calcUptime(state.Running?state.StartedAt:null),
      startedAt:state.StartedAt, exitCode:state.ExitCode,
    };
  }));
  res.json(results.filter(Boolean));
});

app.get('/api/containers/resources', requireAuth, async (req,res) => {
  const running = (await Promise.all(ALLOWED_CONTAINERS.map(async name => {
    const info = await dockerInspect(name);
    if (!info||!info.State.Running) return null;
    const stats = await dockerStats(name);
    return stats ? {name, ...stats} : null;
  }))).filter(Boolean);
  res.json(running);
});

app.post('/api/containers/:name/:action', requireAuth, requireAdmin, async (req,res) => {
  const {name,action} = req.params;
  if (!['start','stop','restart'].includes(action)) return res.status(400).json({error:'Invalid action'});
  if (!ALLOWED_CONTAINERS.includes(name)) return res.status(403).json({error:'Not in allowed list'});
  const result = await dockerAction(name, action);
  await audit(req,'container-'+action,`${action} ${name}`);
  res.json(result);
});

// ════════════════════════════════════════════════════════════════════════════════
// SERVICES (TCP/HTTP checks)
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/services', requireAuth, async (req,res) => {
  try {
    const checks = await Promise.all([
      tcpCheck('smf',9091).then(s=>({key:'smf',label:'SMF (5G)',status:s})),
      tcpCheck('upf',9091).then(s=>({key:'upf',label:'UPF',status:s})),
      tcpCheck('mme',9091).then(s=>({key:'mme',label:'MME (4G)',status:s})),
      tcpCheck('pcrf',3873).then(s=>({key:'pcrf',label:'PCRF (4G)',status:s})),
      tcpCheck('pcscf',3871).then(s=>({key:'pcscf',label:'P-CSCF',status:s})),
      tcpCheck('icscf',4060).then(s=>({key:'icscf',label:'I-CSCF',status:s})),
      tcpCheck('scscf',6060).then(s=>({key:'scscf',label:'S-CSCF',status:s})),
      tcpCheck('smsc',7090).then(s=>({key:'smsc',label:'SMSC',status:s})),
      tcpCheck('osmomsc',2775).then(s=>({key:'osmomsc',label:'OsmoMSC',status:s})),
      tcpCheck('osmohlr',4222).then(s=>({key:'osmohlr',label:'OsmoHLR',status:s})),
      tcpCheck('mongo',27017).then(s=>({key:'mongo',label:'MongoDB',status:s})),
      httpCheck('http://pyhss:8080').then(s=>({key:'hss',label:'HSS/PyHSS',status:s})),
      httpCheck('http://metrics:9090').then(s=>({key:'metrics',label:'Prometheus',status:s})),
      httpCheck('http://grafana:3000').then(s=>({key:'grafana',label:'Grafana',status:s})),
      httpCheck('http://webui:9999').then(s=>({key:'webui',label:'WebUI (orig)',status:s})),
      dockerInspect('sgwc').then(i=>({key:'sgwc',label:'SGW-C (4G)',status:i?.State?.Running?'running':'stopped'})),
      dockerInspect('sgwu').then(i=>({key:'sgwu',label:'SGW-U (4G)',status:i?.State?.Running?'running':'stopped'})),
    ]);
    res.json(checks);
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// SUBSCRIBERS
// ════════════════════════════════════════════════════════════════════════════════
function buildSubscriberDoc(body) {
  const {imsi,msisdn,security,slice} = body;
  return {
    imsi:imsi||'', msisdn:msisdn?[msisdn]:[],
    imeisv:[],mme_host:[],mme_realm:[],purge_flag:[],
    security:{k:security?.k||'',op:security?.op||null,opc:security?.opc||'',amf:security?.amf||'8000',sqn:security?.sqn||0},
    ambr:{downlink:{value:1,unit:3},uplink:{value:1,unit:3}},
    slice:slice||[{sst:1,default_indicator:true,session:[{
      name:'internet',type:3,
      qos:{index:9,arp:{priority_level:8,pre_emption_capability:1,pre_emption_vulnerability:1}},
      ambr:{downlink:{value:1,unit:3},uplink:{value:1,unit:3}},
      ue:{addr:'0.0.0.0'},pcc_rule:[],
    }]}],
    __v:0,
  };
}
app.get('/api/subscribers', requireAuth, async (req,res) => {
  try { res.json(await db.collection('subscribers').find({}).toArray()); }
  catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/api/subscribers', requireAuth, async (req,res) => {
  try {
    const doc = buildSubscriberDoc(req.body);
    const result = await db.collection('subscribers').insertOne(doc);
    await audit(req,'add-subscriber',`Added IMSI ${doc.imsi}`);
    res.json({...doc,_id:result.insertedId});
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.put('/api/subscribers/:id', requireAuth, async (req,res) => {
  try {
    const doc = buildSubscriberDoc(req.body);
    await db.collection('subscribers').replaceOne({_id:new ObjectId(req.params.id)},doc);
    await audit(req,'edit-subscriber',`Edited IMSI ${doc.imsi}`);
    res.json({_id:req.params.id,...doc});
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.delete('/api/subscribers/:id', requireAuth, async (req,res) => {
  try {
    const sub = await db.collection('subscribers').findOne({_id:new ObjectId(req.params.id)});
    await db.collection('subscribers').deleteOne({_id:new ObjectId(req.params.id)});
    await audit(req,'delete-subscriber',`Deleted IMSI ${sub?.imsi}`);
    res.json({ok:true});
  } catch(e) { res.status(500).json({error:e.message}); }
});

// Bulk import
app.post('/api/subscribers/bulk', requireAuth, async (req,res) => {
  const {subscribers} = req.body;
  if (!Array.isArray(subscribers)||!subscribers.length) return res.status(400).json({error:'No subscribers provided'});
  let added=0, skipped=0, errors=[];
  for (const s of subscribers) {
    try {
      if (!s.imsi||!s.k) { errors.push({imsi:s.imsi||'?',error:'Missing IMSI or K'}); continue; }
      const exists = await db.collection('subscribers').findOne({imsi:s.imsi});
      if (exists) { skipped++; continue; }
      const doc = buildSubscriberDoc({
        imsi:s.imsi, msisdn:s.msisdn||'',
        security:{k:s.k,opc:s.opc||'',op:s.op||'',amf:s.amf||'8000'},
        slice:[{sst:parseInt(s.sst)||1,default_indicator:true,session:[{
          name:s.apn||'internet',type:3,
          qos:{index:9,arp:{priority_level:8,pre_emption_capability:1,pre_emption_vulnerability:1}},
          ambr:{downlink:{value:parseInt(s.dl_ambr)||1000,unit:3},uplink:{value:parseInt(s.ul_ambr)||1000,unit:3}},
          ue:{addr:'0.0.0.0'},pcc_rule:[],
        }]}],
      });
      await db.collection('subscribers').insertOne(doc);
      added++;
    } catch(e) { errors.push({imsi:s.imsi,error:e.message}); }
  }
  await audit(req,'bulk-import',`Bulk imported ${added} subscribers, ${skipped} skipped`);
  res.json({added,skipped,errors});
});

// Export
app.get('/api/subscribers/export', requireAuth, async (req,res) => {
  try {
    const subs = await db.collection('subscribers').find({}).toArray();
    await audit(req,'export-subscribers',`Exported ${subs.length} subscribers`);
    res.setHeader('Content-Disposition','attachment; filename="subscribers.json"');
    res.setHeader('Content-Type','application/json');
    res.json(subs);
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// APNs
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/apns', requireAuth, async (req,res) => {
  try {
    const subs = await db.collection('subscribers').find({}).toArray();
    const apns = {};
    subs.forEach(s=>(s.slice||[]).forEach(sl=>(sl.session||[]).forEach(sess=>{
      const name=sess.name||'unknown';
      if(!apns[name]) apns[name]={name,subscriberCount:0,subscribers:[],qos:sess.qos,ambr:sess.ambr};
      apns[name].subscriberCount++;
      apns[name].subscribers.push(s.imsi);
    })));
    res.json(Object.values(apns));
  } catch(e) { res.status(500).json({error:e.message}); }
});

// APN profiles (stored in dashboard for templates)
app.get('/api/apn-profiles', requireAuth, async (req,res) => {
  try { res.json(await db.collection('apn_profiles').find({}).toArray()); }
  catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/api/apn-profiles', requireAuth, requireAdmin, async (req,res) => {
  try {
    const {name,sst,apn,dl_ambr,ul_ambr,qos_index} = req.body;
    if(!name||!apn) return res.status(400).json({error:'Name and APN required'});
    const result = await db.collection('apn_profiles').insertOne({
      name,sst:sst||1,apn,dl_ambr:dl_ambr||1000,ul_ambr:ul_ambr||1000,
      qos_index:qos_index||9,createdAt:new Date(),
    });
    await audit(req,'create-apn-profile',`Created APN profile ${name}`);
    res.json({ok:true,_id:result.insertedId});
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.delete('/api/apn-profiles/:id', requireAuth, requireAdmin, async (req,res) => {
  try {
    await db.collection('apn_profiles').deleteOne({_id:new ObjectId(req.params.id)});
    await audit(req,'delete-apn-profile',`Deleted APN profile ${req.params.id}`);
    res.json({ok:true});
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// NODES
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/nodes', requireAuth, async (req,res) => {
  try {
    const [enbResults,enbUeResults,mmeSessionResults] = await Promise.all([
      promQueryRaw('enb'),promQueryRaw('enb_ue'),promQueryRaw('mme_session'),
    ]);
    const nodes = enbResults.map(r=>{
      const instance=r.metric.instance||'unknown';
      const ueResult=enbUeResults.find(u=>u.metric.instance===instance);
      const sessResult=mmeSessionResults.find(u=>u.metric.instance===instance);
      return {
        instance, job:r.metric.job||'unknown',
        enbCount:parseInt(r.value[1])||0,
        ueCount:ueResult?parseInt(ueResult.value[1]):0,
        sessCount:sessResult?parseInt(sessResult.value[1]):0,
        status:parseInt(r.value[1])>0?'connected':'idle',
      };
    });
    res.json(nodes);
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// IP POOL VIEWER
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/ip-pool', requireAuth, async (req,res) => {
  try {
    // Try to get UE IP assignments from Open5GS sessions collection
    const subs = await db.collection('subscribers').find({},{ projection:{imsi:1,'slice.session.ue':1} }).toArray();
    const assignments = [];
    subs.forEach(s=>(s.slice||[]).forEach(sl=>(sl.session||[]).forEach(sess=>{
      if(sess.ue&&sess.ue.addr&&sess.ue.addr!=='0.0.0.0') {
        assignments.push({imsi:s.imsi,ip:sess.ue.addr,apn:sess.name||'unknown'});
      }
    })));

    // Also check if there's a sessions collection
    let activeSessions = [];
    try {
      const colNames = (await db.listCollections().toArray()).map(c=>c.name);
      if (colNames.includes('sessions')) {
        activeSessions = await db.collection('sessions').find({}).toArray();
      }
    } catch(_) {}

    // Get UE count from Prometheus for context
    const ueCount = await promQuery('enb_ue');
    const activeUEs = await promQuery('ues_active');

    res.json({
      assignments,
      activeSessions: activeSessions.slice(0,50),
      stats:{ connectedUEs:ueCount||0, activePDNSessions:activeUEs||0 },
    });
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// DNS RECORD VIEWER
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/dns', requireAuth, async (req,res) => {
  try {
    // Read zone files directly from the BIND container
    function readZoneFile(path) {
      return new Promise(resolve => {
        exec(`docker exec dns cat ${path} 2>/dev/null`, {timeout:3000}, (err,stdout) => {
          resolve(err ? null : stdout);
        });
      });
    }

    // Parse A records from a BIND zone file
    function parseZoneRecords(zoneContent, zoneName) {
      if (!zoneContent) return [];
      const records = [];
      const lines = zoneContent.split('\n');
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith(';') || trimmed.startsWith('$') || trimmed.startsWith('@')) continue;
        const aMatch = trimmed.match(/^(\S+)\s+\S+\s+IN\s+A\s+(\d+\.\d+\.\d+\.\d+)/i);
        if (aMatch) records.push({ name: aMatch[1] + '.' + zoneName, type: 'A', address: aMatch[2] });
        const srvMatch = trimmed.match(/^(\S+)\s+\S+\s+SRV\s+\d+\s+\d+\s+(\d+)\s+(\S+)/i);
        if (srvMatch) records.push({ name: aMatch ? aMatch[1] : srvMatch[1], type: 'SRV', address: srvMatch[3] + ':' + srvMatch[2] });
      }
      return records;
    }

    const [imsZone, epcZone, namedConf] = await Promise.all([
      readZoneFile('/etc/bind/ims_zone'),
      readZoneFile('/etc/bind/epc_zone'),
      readZoneFile('/etc/bind/named.conf.local'),
    ]);

    const imsRecords = parseZoneRecords(imsZone, 'ims.mnc990.mcc314.3gppnetwork.org');
    const epcRecords = parseZoneRecords(epcZone, 'epc.mnc990.mcc314.3gppnetwork.org');

    res.json({
      zones: [
        { name: 'ims.mnc990.mcc314.3gppnetwork.org', records: imsRecords, raw: imsZone },
        { name: 'epc.mnc990.mcc314.3gppnetwork.org', records: epcRecords, raw: epcZone },
      ],
      namedConf,
    });
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// ALARM / EVENT FEED
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/alarms', requireAuth, async (req,res) => {
  try {
    const containers = ['mme','smf','upf','pcscf','icscf','scscf','pyhss','osmomsc'];
    const lines = 50;

    const logs = await Promise.all(containers.map(name => new Promise(resolve => {
      exec(`docker logs ${name} --tail=${lines} 2>&1`, {timeout:5000}, (err,stdout) => {
        if (err&&!stdout) return resolve([]);
        const entries = stdout.split('\n').filter(Boolean).slice(-lines).map(line => {
          let level = 'info';
          const l = line.toLowerCase();
          if (l.includes('error')||l.includes('failed')||l.includes('fatal')) level='error';
          else if (l.includes('warn')||l.includes('warning')) level='warn';
          else if (l.includes('connect')||l.includes('attach')||l.includes('register')||l.includes('success')) level='ok';
          return {container:name, line:line.substring(0,200), level};
        });
        resolve(entries);
      });
    })));

    const all = logs.flat()
      .filter(e=>e.level!=='info'||e.line.match(/connect|attach|register|success|handover/i))
      .slice(-200);

    res.json(all);
  } catch(e) { res.status(500).json({error:e.message}); }
});

// ════════════════════════════════════════════════════════════════════════════════
// PYHSS MANAGEMENT
// ════════════════════════════════════════════════════════════════════════════════
app.get('/api/pyhss/status', requireAuth, async (req,res) => {
  try {
    if (!pyhssUrl) { await discoverPyHSS(); }
    if (!pyhssUrl) return res.json({available:false});
    const r = await pyhssFetch('/');
    res.json({available:true,url:pyhssUrl,status:r.status});
  } catch(e) { res.json({available:false,error:e.message}); }
});
app.get('/api/pyhss/subscribers', requireAuth, async (req,res) => {
  try {
    const r = await pyhssFetch('/api/v1/subscriber/');
    res.json(r.body);
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.get('/api/pyhss/roaming', requireAuth, async (req,res) => {
  try {
    const r = await pyhssFetch('/api/v1/roaming/');
    res.json(r.body);
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.get('/api/pyhss/auc', requireAuth, async (req,res) => {
  try {
    const r = await pyhssFetch('/api/v1/auc/');
    res.json(r.body);
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.listen(PORT, () => console.log(`Open5GS Dashboard API on :${PORT}`));
