#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  Open5GS Enhanced Dashboard — Install Script
# ═══════════════════════════════════════════════════════════════
set -e

CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${CYAN}[INFO]${NC} $1"; }
ok()    { echo -e "${GREEN}[OK]${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     Open5GS Enhanced Dashboard Installer    ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════╝${NC}"
echo ""

# ── Check prerequisites ─────────────────────────────────────────
info "Checking prerequisites..."
command -v docker >/dev/null 2>&1 || error "Docker is not installed. Install Docker first."
command -v docker-compose >/dev/null 2>&1 || docker compose version >/dev/null 2>&1 || error "Docker Compose is not installed."
ok "Docker and Docker Compose found"

# ── Configuration ───────────────────────────────────────────────
INSTALL_DIR="${1:-$HOME/docker_open5gs}"
DASHBOARD_DIR="$INSTALL_DIR/open5gs-dashboard"
COMPOSE_FILE="$INSTALL_DIR/docker-compose.dashboard.yml"

echo ""
info "Install directory: $INSTALL_DIR"
info "Dashboard will be available at: http://$(hostname -I | awk '{print $1}'):3080"
echo ""

# Check if Open5GS stack is running
DOCKER_NETWORK="docker_open5gs_default"
if ! docker network inspect "$DOCKER_NETWORK" >/dev/null 2>&1; then
    warn "Docker network '$DOCKER_NETWORK' not found."
    warn "Make sure your Open5GS stack is running first."
    warn "The dashboard will still install but may not connect."
    echo ""
fi

# Check for MongoDB container
if docker ps --format '{{.Names}}' | grep -q "^mongo$"; then
    ok "MongoDB container 'mongo' found and running"
else
    warn "MongoDB container 'mongo' not found or not running"
    warn "Make sure your Open5GS stack includes a MongoDB container named 'mongo'"
fi

echo ""
read -p "Continue with installation? (y/N) " -n 1 -r
echo ""
[[ ! $REPLY =~ ^[Yy]$ ]] && { info "Installation cancelled."; exit 0; }

# ── Install files ───────────────────────────────────────────────
info "Creating dashboard directory..."
mkdir -p "$DASHBOARD_DIR/backend"
mkdir -p "$DASHBOARD_DIR/frontend"
mkdir -p "$DASHBOARD_DIR/nginx"

# Copy files from script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

info "Copying dashboard files..."
cp "$SCRIPT_DIR/backend/server.js"       "$DASHBOARD_DIR/backend/server.js"
cp "$SCRIPT_DIR/backend/package.json"    "$DASHBOARD_DIR/backend/package.json"
cp "$SCRIPT_DIR/frontend/index.html"     "$DASHBOARD_DIR/frontend/index.html"
cp "$SCRIPT_DIR/nginx/default.conf"      "$DASHBOARD_DIR/nginx/default.conf"
cp "$SCRIPT_DIR/Dockerfile"              "$DASHBOARD_DIR/Dockerfile"
cp "$SCRIPT_DIR/supervisord.conf"        "$DASHBOARD_DIR/supervisord.conf"
cp "$SCRIPT_DIR/docker-compose.dashboard.yml" "$COMPOSE_FILE"

ok "Files copied successfully"

# ── Create update helper scripts ────────────────────────────────
info "Creating helper scripts..."

cat > "$HOME/dashboard-update-backend.sh" << 'SCRIPTEOF'
#!/bin/bash
# Copy updated server.js into the dashboard directory and rebuild
INSTALL_DIR="${1:-$HOME/docker_open5gs}"
cp "$(dirname "$0")/open5gs-dashboard/backend/server.js" "$INSTALL_DIR/open5gs-dashboard/backend/server.js" 2>/dev/null || true
cd "$INSTALL_DIR"
docker compose -f docker-compose.dashboard.yml up -d --build --force-recreate
echo "Backend updated and restarted"
SCRIPTEOF

cat > "$HOME/dashboard-update-frontend.sh" << 'SCRIPTEOF'
#!/bin/bash
# Copy updated index.html into the dashboard directory and rebuild
INSTALL_DIR="${1:-$HOME/docker_open5gs}"
cp "$(dirname "$0")/open5gs-dashboard/frontend/index.html" "$INSTALL_DIR/open5gs-dashboard/frontend/index.html" 2>/dev/null || true
cd "$INSTALL_DIR"
docker compose -f docker-compose.dashboard.yml up -d --build --force-recreate
echo "Frontend updated and restarted"
SCRIPTEOF

cat > "$HOME/dashboard-logs.sh" << 'SCRIPTEOF'
#!/bin/bash
docker logs open5gs-dashboard --tail=${1:-50} -f
SCRIPTEOF

cat > "$HOME/dashboard-reset-password.sh" << 'SCRIPTEOF'
#!/bin/bash
# Reset admin password to 'admin'
NEW_PASS="${1:-admin}"
docker exec -it mongo mongosh open5gs --eval "
const crypto = require('crypto');
const salt = crypto.randomBytes(16).toString('hex');
const hash = crypto.createHmac('sha256', salt).update('$NEW_PASS').digest('hex');
db.dashboard_users.updateOne(
  {username: 'admin'},
  {\$set: {hash: hash, salt: salt, mustChangePassword: false}},
  {upsert: false}
);
print('Admin password reset to: $NEW_PASS');
"
SCRIPTEOF

chmod +x "$HOME/dashboard-update-backend.sh"
chmod +x "$HOME/dashboard-update-frontend.sh"
chmod +x "$HOME/dashboard-logs.sh"
chmod +x "$HOME/dashboard-reset-password.sh"
ok "Helper scripts created in $HOME/"

# ── Build and start ─────────────────────────────────────────────
info "Building and starting dashboard container..."
cd "$INSTALL_DIR"
docker compose -f docker-compose.dashboard.yml up -d --build

# Wait for it to start
info "Waiting for dashboard to start..."
sleep 5

if docker ps --format '{{.Names}}' | grep -q "^open5gs-dashboard$"; then
    ok "Dashboard container is running"
else
    error "Dashboard container failed to start. Run: docker logs open5gs-dashboard"
fi

# ── Initialize admin user ───────────────────────────────────────
info "Setting up admin user in MongoDB..."
sleep 3  # Give backend time to connect to MongoDB

docker exec open5gs-dashboard node -e "
const {MongoClient} = require('mongodb');
const crypto = require('crypto');
const client = new MongoClient(process.env.MONGO_URI || 'mongodb://mongo:27017/open5gs');
client.connect().then(async () => {
  const db = client.db('open5gs');
  const col = db.collection('dashboard_users');
  const existing = await col.findOne({username: 'admin'});
  if (!existing) {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.createHmac('sha256', salt).update('admin').digest('hex');
    await col.insertOne({username:'admin',hash,salt,role:'admin',mustChangePassword:false,createdAt:new Date()});
    console.log('Admin user created (password: admin)');
  } else {
    console.log('Admin user already exists');
  }
  await client.close();
}).catch(e => console.log('MongoDB note:', e.message));
" 2>/dev/null || warn "Could not initialize admin user - you may need to do this manually"

# ── Done ────────────────────────────────────────────────────────
SERVER_IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║        Installation Complete!                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Dashboard URL:  ${CYAN}http://$SERVER_IP:3080${NC}"
echo -e "  Default login:  ${CYAN}admin / admin${NC}"
echo ""
echo -e "  Helper scripts:"
echo -e "    ${YELLOW}~/dashboard-logs.sh${NC}              — View live logs"
echo -e "    ${YELLOW}~/dashboard-reset-password.sh${NC}    — Reset admin password"
echo -e "    ${YELLOW}~/dashboard-update-frontend.sh${NC}   — Update frontend"
echo -e "    ${YELLOW}~/dashboard-update-backend.sh${NC}    — Update backend"
echo ""
echo -e "  To stop:   ${YELLOW}cd $INSTALL_DIR && docker compose -f docker-compose.dashboard.yml down${NC}"
echo -e "  To start:  ${YELLOW}cd $INSTALL_DIR && docker compose -f docker-compose.dashboard.yml up -d${NC}"
echo ""
echo -e "${YELLOW}  IMPORTANT: Change your admin password after first login!${NC}"
echo ""
